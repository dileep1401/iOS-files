//
//  ViewController.swift
//  TASK-7
//
//  Created by ROY on 28/11/24.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource{
    
    @IBOutlet var table1 : UITableView!
    @IBOutlet var table2 : UITableView!
    
    var Section1 : [String] = []
    var Section2 : [String] = []
    var Section3 : [String] = []
    var Section4 : [String] = []
    var Section5 : [String] = []
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        Section1 = ["Harsh","Akki", "Sham",]
        Section2 = ["15","16","17"]
        Section3 = ["Thar","Lambo", "Defender",]
        Section4 = ["Black","Red","Wine Red"]
        Section5 = ["LOL","IDC", "LMAO",]
        table1.delegate = self
        table1.dataSource = self
        table2.delegate = self
        table2.dataSource = self
    }
    //tableview protocol methods implementation
    //1.number of sections
    func numberOfSections(in tableView: UITableView) -> Int {
        if tableView == table1 {
            return 2
        } else {
            return 2
        }
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if tableView == table1 {
                   if section == 0 {
                       return Section1.count
                   }else {
                       return Section2.count
                   }
               }
               else {
                   if section == 0 {
                       return Section3.count
                   }else if section == 1 {
                       return Section4.count
                   }else {
                       return Section5.count
                   }
               }
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if tableView == table1 {
            let cell1 = tableView.dequeueReusableCell(withIdentifier: "id1", for: indexPath)
            if indexPath.section == 0 {
               
                cell1.textLabel?.text = Section1[indexPath.row]
            } else {
                // Fill with data from array2
                cell1.textLabel?.text = Section2[indexPath.row]
            }
            return cell1
        } else {
            let cell2 = tableView.dequeueReusableCell(withIdentifier: "id2", for: indexPath)
            if indexPath.section == 0 {
               
                cell2.textLabel?.text = Section3[indexPath.row]
            } else if indexPath.section == 1 {
                
                cell2.textLabel?.text = Section4[indexPath.row]
            } else {
                cell2.textLabel?.text = Section5[indexPath.row]
            }
            return cell2
        }
    }
    
    //4.section header title
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        if tableView == table1 {
            if section == 0 {
                return "Names"
            } else {
                return "44"
            }
        } else {
            if section == 0 {
                return "Cars"
            } else if section == 1{
                return "33"
            } else {
                return "Names"
            }
        }
        
    }
    //5.section footer title
    func tableView(_ tableView: UITableView, titleForFooterInSection section: Int) -> String? {
        if tableView == table1 {
            if section == 0 {
                return "List of 22"
            } else {
                return "Numbers"
            }
        } else {
            if section == 0 {
                return "List of IOS"
            } else if section == 1{
                return "List of 11"
            } else {
                return "Shortcuts"
            }
        }
        
    }
}

    


    
    
    
        
