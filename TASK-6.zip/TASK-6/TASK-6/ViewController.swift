//
//  ViewController.swift
//  TASK-6
//
//  Created by ROY on 28/11/24.
//

import UIKit

class ViewController: UIViewController, UIPickerViewDelegate,UIPickerViewDataSource  {
    
    @IBOutlet var pv1 : UIPickerView!
    @IBOutlet var label1: UILabel!
    @IBOutlet var img : UIImageView!
    let imgNames1 = ["image 1.jpeg","image 2.jpeg"]
    let imgNames2 = ["image 3.jpeg","image 4.jpeg"]
    
    
    var array1: [String] = []
    var array2: [String] = []
    var array3: [String] = []
    var array4: [String] = []
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        array1 = ["Defender","Lambo"]
        array2 = ["iphone","samsung","oneplus"]
        array3 = ["Red","Black"]
        array4 = ["imac","Macbook"]
        
    
        img.image = UIImage(named: imgNames1[0])
       
        img.image = UIImage(named: imgNames2[0])
        
        pv1.delegate = self
        pv1.dataSource = self
    
        
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
            return 2
            
            
        }
        func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
            
            if component == 0 {
                return array1.count
            }
            else {
                
                return array2.count
            }
        }
        
        
        func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
            
            if component == 0 {
                return array1[row]
            }
            else {
                return array2[row]
            }
            
        }
        func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
            if component == 0 {
                label1.text = array1[row]
                img.image = UIImage(named: imgNames1[row])
            }
            else {
                label1.text = array2[row]
                img.image = UIImage(named: imgNames2[row])
            }
        }
        
        func pickerView(_ pickerView: UIPickerView, rowHeightForComponent component: Int) -> CGFloat {
            return 40
        }
        //6.row width
        
        func pickerView(_ pickerView: UIPickerView, widthForComponent component: Int) -> CGFloat {
            return 150
            
        }
            

    }
    
    
    
    
