//
//  ViewController.swift
//  task4
//
//  Created by shamitha on 25/11/24.
//

import UIKit
import WebKit

class ViewController: UIViewController {
    
    @IBOutlet var wv: WKWebView!
    @IBOutlet var  sc1: UISegmentedControl!
    
    var URL1 : URL!
    var request1: URLRequest!
    
    var URL2 : URL!
    var request2: URLRequest!
    
    var URL3 : URL!
    var request3: URLRequest!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    @IBAction func sc1Click(){
        let index = sc1.selectedSegmentIndex
        if index == 0{
            URL1 = URL(string: "https://www.apple.com")!
            request1 = URLRequest(url: URL1)
            wv.load(request1)
        }
        if index == 1{
            URL2 = URL(string: "https://www.google.com")!
            request2 = URLRequest(url: URL2)
            wv.load(request2)
        }
        if index == 2{
            URL3 = URL(string: "https://www.instagram.com")!
            request3 = URLRequest(url: URL3)
            wv.load(request3)
        }
        
        
    }
    
}
